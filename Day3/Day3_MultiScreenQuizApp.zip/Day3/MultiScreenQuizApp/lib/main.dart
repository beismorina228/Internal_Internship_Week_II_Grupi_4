import 'package:flutter/material.dart';

void main() {
  runApp(const QuizApp());
}

class Question {
  const Question({
    required this.text,
    required this.options,
    required this.correctAnswerIndex,
  });

  final String text;
  final List<String> options;
  final int correctAnswerIndex;
}

class QuizApp extends StatelessWidget {
  const QuizApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Multi-screen Quiz App',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6750A4),
        ),
        useMaterial3: true,
      ),
      home: const QuizScreen(),
    );
  }
}

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  final List<Question> questions = const [
    Question(
      text: 'Cila gjuhë programuese përdoret nga Flutter?',
      options: ['Python', 'Dart', 'JavaScript', 'C'],
      correctAnswerIndex: 1,
    ),
    Question(
      text: 'Cili widget krijon strukturën bazë të ekranit?',
      options: ['Container', 'Scaffold', 'Text', 'Icon'],
      correctAnswerIndex: 1,
    ),
    Question(
      text: 'Çfarë bën setState()?',
      options: [
        'Mbyll app-in',
        'Fshin të dhënat',
        'Rifreskon UI-në',
        'Krijon projekt të ri',
      ],
      correctAnswerIndex: 2,
    ),
    Question(
      text: 'Cila metodë hap një ekran të ri?',
      options: [
        'Navigator.push()',
        'Navigator.close()',
        'Navigator.start()',
        'Navigator.delete()',
      ],
      correctAnswerIndex: 0,
    ),
    Question(
      text: 'Cili widget shfaq një listë dinamike?',
      options: [
        'ListView.builder',
        'AppBar',
        'CircleAvatar',
        'Divider',
      ],
      correctAnswerIndex: 0,
    ),
  ];

  int currentQuestionIndex = 0;
  int score = 0;
  bool processingAnswer = false;

  Future<void> selectAnswer(int selectedIndex) async {
    if (processingAnswer) return;

    setState(() {
      processingAnswer = true;
    });

    final question = questions[currentQuestionIndex];
    final isCorrect = selectedIndex == question.correctAnswerIndex;

    if (isCorrect) {
      score++;
    }

    final isLastQuestion =
        currentQuestionIndex == questions.length - 1;

    if (isLastQuestion) {
      final restart = await Navigator.push<bool>(
        context,
        MaterialPageRoute<bool>(
          builder: (_) => ResultScreen(
            score: score,
            totalQuestions: questions.length,
          ),
        ),
      );

      if (!mounted) return;

      if (restart == true) {
        restartQuiz();
      } else {
        setState(() {
          processingAnswer = false;
        });
      }
      return;
    }

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(
            isCorrect
                ? 'Përgjigje e saktë!'
                : 'Përgjigje e pasaktë.',
          ),
          duration: const Duration(milliseconds: 700),
        ),
      );

    await Future<void>.delayed(const Duration(milliseconds: 350));
    if (!mounted) return;

    setState(() {
      currentQuestionIndex++;
      processingAnswer = false;
    });
  }

  void restartQuiz() {
    setState(() {
      currentQuestionIndex = 0;
      score = 0;
      processingAnswer = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Quiz-i filloi përsëri.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final question = questions[currentQuestionIndex];
    final progress =
        (currentQuestionIndex + 1) / questions.length;

    return Scaffold(
      backgroundColor: const Color(0xFFF6F3FB),
      appBar: AppBar(
        title: const Text('Multi-screen Quiz App'),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: Text(
                'Pikët: $score',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final isDesktop = constraints.maxWidth >= 760;

            return SingleChildScrollView(
              padding: const EdgeInsets.all(18),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 850),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: LinearProgressIndicator(
                              value: progress,
                              minHeight: 10,
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Text(
                            '${currentQuestionIndex + 1}/${questions.length}',
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),
                      Card(
                        elevation: 4,
                        child: Padding(
                          padding: EdgeInsets.all(isDesktop ? 34 : 22),
                          child: Column(
                            children: [
                              const Icon(
                                Icons.quiz_outlined,
                                size: 58,
                                color: Color(0xFF6750A4),
                              ),
                              const SizedBox(height: 16),
                              Text(
                                'Pyetja ${currentQuestionIndex + 1}',
                                style: const TextStyle(
                                  color: Color(0xFF6750A4),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                question.text,
                                textAlign: TextAlign.center,
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineSmall
                                    ?.copyWith(
                                      fontWeight: FontWeight.bold,
                                    ),
                              ),
                              const SizedBox(height: 26),
                              GridView.builder(
                                shrinkWrap: true,
                                physics:
                                    const NeverScrollableScrollPhysics(),
                                itemCount: question.options.length,
                                gridDelegate:
                                    SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: isDesktop ? 2 : 1,
                                  crossAxisSpacing: 14,
                                  mainAxisSpacing: 14,
                                  childAspectRatio: isDesktop ? 4.8 : 5.2,
                                ),
                                itemBuilder: (context, index) {
                                  return FilledButton.tonal(
                                    onPressed: processingAnswer
                                        ? null
                                        : () => selectAnswer(index),
                                    style: FilledButton.styleFrom(
                                      alignment: Alignment.centerLeft,
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 18,
                                      ),
                                    ),
                                    child: Row(
                                      children: [
                                        CircleAvatar(
                                          radius: 16,
                                          child: Text(
                                            String.fromCharCode(65 + index),
                                            style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 12),
                                        Expanded(
                                          child: Text(
                                            question.options[index],
                                            style:
                                                const TextStyle(fontSize: 16),
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class ResultScreen extends StatelessWidget {
  const ResultScreen({
    super.key,
    required this.score,
    required this.totalQuestions,
  });

  final int score;
  final int totalQuestions;

  String get message {
    final percentage = score / totalQuestions;

    if (percentage == 1) {
      return 'Shkëlqyeshëm! Të gjitha përgjigjet janë të sakta.';
    }
    if (percentage >= 0.6) {
      return 'Punë shumë e mirë! E kalove quiz-in.';
    }
    return 'Duhet pak më shumë ushtrim. Provo përsëri!';
  }

  @override
  Widget build(BuildContext context) {
    final percentage = score / totalQuestions * 100;

    return Scaffold(
      backgroundColor: const Color(0xFFF6F3FB),
      appBar: AppBar(
        title: const Text('Rezultati'),
        centerTitle: true,
        automaticallyImplyLeading: false,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 600),
              child: Card(
                elevation: 5,
                child: Padding(
                  padding: const EdgeInsets.all(28),
                  child: Column(
                    children: [
                      const Icon(
                        Icons.emoji_events,
                        size: 90,
                        color: Color(0xFF6750A4),
                      ),
                      const SizedBox(height: 20),
                      Text(
                        'Quiz-i përfundoi!',
                        style: Theme.of(context)
                            .textTheme
                            .headlineMedium
                            ?.copyWith(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 22),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(22),
                        decoration: BoxDecoration(
                          color: const Color(0xFFEDE7F6),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Column(
                          children: [
                            Text(
                              '$score / $totalQuestions',
                              style: Theme.of(context)
                                  .textTheme
                                  .displaySmall
                                  ?.copyWith(
                                    fontWeight: FontWeight.bold,
                                    color: const Color(0xFF4F378B),
                                  ),
                            ),
                            Text(
                              '${percentage.toStringAsFixed(0)}%',
                              style: Theme.of(context)
                                  .textTheme
                                  .titleLarge,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 22),
                      Text(
                        message,
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 28),
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: FilledButton.icon(
                          onPressed: () {
                            Navigator.pop(context, true);
                          },
                          icon: const Icon(Icons.restart_alt),
                          label: const Text('Fillo përsëri'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
