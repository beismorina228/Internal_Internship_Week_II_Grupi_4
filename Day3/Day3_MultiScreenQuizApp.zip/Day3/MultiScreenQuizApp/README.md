# Day 3 – Multi-screen Quiz App

Ky projekt është krijuar për detyrën **Internal Internship – Day 3**.

## Çfarë funksionon

- 5 pyetje me nga 4 opsione.
- Ruajtja e pikëve dhe pyetjes aktuale me state.
- Kontrollimi i përgjigjeve të sakta.
- Feedback me SnackBar.
- Kalimi në ekranin e rezultatit me Navigator.push().
- Restart me Navigator.pop(context, true).
- Ekran final me pikë, përqindje dhe mesazh.
- UI responsive për mobile dhe desktop.
- Model class `Question`.

## Si të ekzekutohet

```bash
flutter create .
flutter pub get
flutter run -d chrome
```

## GitHub

```bash
git add .
git commit -m "day3 quiz navigation"
git push
```

## Screenshot

Vendose screenshot-in në:

```text
screenshots/quiz_app.png
```

## Çfarë mund të shtohet më vonë

- timer për çdo pyetje;
- kategori të ndryshme;
- përzierje automatike e pyetjeve;
- ruajtje e rezultateve;
- pyetje nga API ose database.
