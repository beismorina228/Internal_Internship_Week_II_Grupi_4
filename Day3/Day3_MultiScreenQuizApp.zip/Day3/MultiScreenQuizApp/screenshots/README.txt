Vendose këtu screenshot-in: quiz_app.png
