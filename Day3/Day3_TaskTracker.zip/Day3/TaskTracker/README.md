# Day 3 – Task Tracker

Ky projekt është krijuar për **Internal Internship – Day 3, Task 2**.

## Përshkrimi

Task Tracker është një aplikacion Flutter që menaxhon një listë dinamike të detyrave.

## Çfarë funksionon

- Model class `TaskItem`.
- Shtimi i një detyre përmes `AlertDialog`.
- Validim që titulli të mos jetë bosh.
- Ndryshimi i statusit `Active / Done`.
- Fshirja me konfirmim.
- Rikthimi i detyrës së fshirë përmes `SnackBarAction`.
- Filtrim: të gjitha, aktive dhe të përfunduara.
- Numërimi i totalit, aktiveve dhe të përfunduarave.
- UI responsive për mobile dhe desktop.

## Struktura

```text
lib/
├── main.dart
├── models/
│   └── task_item.dart
└── screens/
    └── task_tracker_screen.dart
```

## Ekzekutimi

```bash
flutter create .
flutter pub get
flutter run -d chrome
```

## GitHub

```bash
git add .
git commit -m "day3 tracker state"
git push
```

## Screenshot

Vendose screenshot-in në:

```text
screenshots/task_tracker.png
```

## Çfarë mund të shtohet më vonë

- editimi i titullit;
- afat përfundimi;
- kategori;
- ruajtje lokale;
- database ose API.
