import 'package:flutter_test/flutter_test.dart';
import 'package:day3_task_tracker/main.dart';

void main() {
  testWidgets('Task tracker loads', (WidgetTester tester) async {
    await tester.pumpWidget(const TaskTrackerApp());

    expect(find.text('Task Tracker'), findsOneWidget);
    expect(find.text('Menaxho detyrat e tua'), findsOneWidget);
    expect(find.text('Shto detyrë'), findsOneWidget);
  });
}
