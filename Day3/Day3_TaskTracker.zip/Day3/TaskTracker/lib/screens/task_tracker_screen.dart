import 'package:flutter/material.dart';

import '../models/task_item.dart';

enum TaskFilter {
  all,
  active,
  done,
}

class TaskTrackerScreen extends StatefulWidget {
  const TaskTrackerScreen({super.key});

  @override
  State<TaskTrackerScreen> createState() => _TaskTrackerScreenState();
}

class _TaskTrackerScreenState extends State<TaskTrackerScreen> {
  final List<TaskItem> _tasks = <TaskItem>[
    TaskItem(title: 'Mëso setState()'),
    TaskItem(title: 'Përfundo Task Tracker'),
    TaskItem(title: 'Bëj commit në GitHub', isDone: true),
  ];

  TaskFilter _selectedFilter = TaskFilter.all;

  int get _totalTasks => _tasks.length;
  int get _doneTasks => _tasks.where((TaskItem task) => task.isDone).length;
  int get _activeTasks => _tasks.where((TaskItem task) => !task.isDone).length;

  List<TaskItem> get _filteredTasks {
    switch (_selectedFilter) {
      case TaskFilter.active:
        return _tasks.where((TaskItem task) => !task.isDone).toList();
      case TaskFilter.done:
        return _tasks.where((TaskItem task) => task.isDone).toList();
      case TaskFilter.all:
        return List<TaskItem>.from(_tasks);
    }
  }

  Future<void> _showAddTaskDialog() async {
    final TextEditingController taskController = TextEditingController();

    final String? newTaskTitle = await showDialog<String>(
      context: context,
      builder: (BuildContext dialogContext) {
        String? errorText;

        return StatefulBuilder(
          builder: (
            BuildContext context,
            void Function(void Function()) setDialogState,
          ) {
            void submitTask() {
              final String title = taskController.text.trim();

              if (title.isEmpty) {
                setDialogState(() {
                  errorText = 'Titulli nuk mund të jetë bosh.';
                });
                return;
              }

              Navigator.pop(dialogContext, title);
            }

            return AlertDialog(
              title: const Text('Shto detyrë të re'),
              content: TextField(
                controller: taskController,
                autofocus: true,
                textInputAction: TextInputAction.done,
                onSubmitted: (_) => submitTask(),
                decoration: InputDecoration(
                  labelText: 'Titulli i detyrës',
                  hintText: 'P.sh. Mëso navigation',
                  errorText: errorText,
                  border: const OutlineInputBorder(),
                ),
              ),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Anulo'),
                ),
                FilledButton(
                  onPressed: submitTask,
                  child: const Text('Shto'),
                ),
              ],
            );
          },
        );
      },
    );

    taskController.dispose();

    if (newTaskTitle == null || !mounted) {
      return;
    }

    setState(() {
      _tasks.add(TaskItem(title: newTaskTitle));
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('U shtua: $newTaskTitle')),
    );
  }

  void _toggleTask(TaskItem task) {
    setState(() {
      task.isDone = !task.isDone;
    });

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(
            task.isDone
                ? 'Detyra u shënua si e përfunduar.'
                : 'Detyra u kthye në aktive.',
          ),
        ),
      );
  }

  Future<void> _deleteTask(TaskItem task) async {
    final bool? shouldDelete = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Konfirmo fshirjen'),
          content: Text('A dëshiron ta fshish detyrën "${task.title}"?'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Anulo'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Fshije'),
            ),
          ],
        );
      },
    );

    if (shouldDelete != true || !mounted) {
      return;
    }

    final int originalIndex = _tasks.indexOf(task);

    setState(() {
      _tasks.remove(task);
    });

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text('U fshi: ${task.title}'),
          action: SnackBarAction(
            label: 'KTHEJE',
            onPressed: () {
              setState(() {
                final int safeIndex = originalIndex.clamp(0, _tasks.length);
                _tasks.insert(safeIndex, task);
              });
            },
          ),
        ),
      );
  }

  void _changeFilter(TaskFilter filter) {
    setState(() {
      _selectedFilter = filter;
    });
  }

  Widget _buildSummaryCard({
    required String title,
    required int value,
    required IconData icon,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: <Widget>[
            CircleAvatar(child: Icon(icon)),
            const SizedBox(width: 14),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(title),
                Text(
                  '$value',
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTaskCard(TaskItem task) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: Checkbox(
          value: task.isDone,
          onChanged: (_) => _toggleTask(task),
        ),
        title: Text(
          task.title,
          style: TextStyle(
            decoration: task.isDone ? TextDecoration.lineThrough : null,
            color: task.isDone ? Colors.grey : null,
            fontWeight: FontWeight.w600,
          ),
        ),
        subtitle: Text(task.isDone ? 'Done' : 'Active'),
        trailing: IconButton(
          tooltip: 'Fshije detyrën',
          onPressed: () => _deleteTask(task),
          icon: const Icon(Icons.delete_outline),
        ),
        onTap: () => _toggleTask(task),
      ),
    );
  }

  Widget _buildFilterBar() {
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: <Widget>[
        ChoiceChip(
          label: Text('Të gjitha ($_totalTasks)'),
          selected: _selectedFilter == TaskFilter.all,
          onSelected: (_) => _changeFilter(TaskFilter.all),
        ),
        ChoiceChip(
          label: Text('Aktive ($_activeTasks)'),
          selected: _selectedFilter == TaskFilter.active,
          onSelected: (_) => _changeFilter(TaskFilter.active),
        ),
        ChoiceChip(
          label: Text('Done ($_doneTasks)'),
          selected: _selectedFilter == TaskFilter.done,
          onSelected: (_) => _changeFilter(TaskFilter.done),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<TaskItem> visibleTasks = _filteredTasks;

    return Scaffold(
      backgroundColor: const Color(0xFFF6F3FB),
      appBar: AppBar(
        title: const Text('Task Tracker'),
        centerTitle: true,
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddTaskDialog,
        icon: const Icon(Icons.add),
        label: const Text('Shto detyrë'),
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
            final bool desktopLayout = constraints.maxWidth >= 800;

            return SingleChildScrollView(
              padding: const EdgeInsets.all(18),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1000),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Text(
                        'Menaxho detyrat e tua',
                        style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                      const SizedBox(height: 6),
                      const Text('Shto, përfundo dhe fshi detyra dinamike.'),
                      const SizedBox(height: 20),
                      if (desktopLayout)
                        Row(
                          children: <Widget>[
                            Expanded(
                              child: _buildSummaryCard(
                                title: 'Gjithsej',
                                value: _totalTasks,
                                icon: Icons.list_alt,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _buildSummaryCard(
                                title: 'Aktive',
                                value: _activeTasks,
                                icon: Icons.pending_actions,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _buildSummaryCard(
                                title: 'Të përfunduara',
                                value: _doneTasks,
                                icon: Icons.task_alt,
                              ),
                            ),
                          ],
                        )
                      else
                        Column(
                          children: <Widget>[
                            _buildSummaryCard(
                              title: 'Gjithsej',
                              value: _totalTasks,
                              icon: Icons.list_alt,
                            ),
                            _buildSummaryCard(
                              title: 'Aktive',
                              value: _activeTasks,
                              icon: Icons.pending_actions,
                            ),
                            _buildSummaryCard(
                              title: 'Të përfunduara',
                              value: _doneTasks,
                              icon: Icons.task_alt,
                            ),
                          ],
                        ),
                      const SizedBox(height: 18),
                      _buildFilterBar(),
                      const SizedBox(height: 20),
                      if (visibleTasks.isEmpty)
                        const Card(
                          child: Padding(
                            padding: EdgeInsets.all(28),
                            child: Column(
                              children: <Widget>[
                                Icon(Icons.inbox_outlined, size: 54),
                                SizedBox(height: 12),
                                Text(
                                  'Nuk ka detyra në këtë kategori.',
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          ),
                        )
                      else
                        ...visibleTasks.map(_buildTaskCard),
                      const SizedBox(height: 90),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
