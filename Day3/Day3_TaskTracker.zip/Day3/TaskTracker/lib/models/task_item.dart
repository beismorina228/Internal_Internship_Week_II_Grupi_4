class TaskItem {
  TaskItem({
    required this.title,
    this.isDone = false,
  });

  String title;
  bool isDone;
}
