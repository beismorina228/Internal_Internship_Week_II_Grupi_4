Vendose këtu screenshot-in pas ekzekutimit.
Emër i rekomanduar: task_tracker.png
