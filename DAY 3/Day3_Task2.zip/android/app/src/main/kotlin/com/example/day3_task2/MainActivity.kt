package com.example.day3_task2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
