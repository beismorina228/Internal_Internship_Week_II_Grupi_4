# Task Tracker App

## Description

A simple Flutter application for managing tasks.

Features:
- Add tasks
- Mark tasks as completed
- Delete tasks
- Task counter
- Completed task counter
- SnackBar notifications

## Technologies

- Flutter
- Dart
- Material Design

## Screenshots

### Home Screen
(Add screenshot here)

## How to Run

flutter pub get
flutter run
