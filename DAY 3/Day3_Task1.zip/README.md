Day3_Quiz App
Description

This is a Flutter quiz application created for Internal Internship - Day 3 Task 1.

The app contains:

5 quiz questions
4 answer options for each question
Score tracking
Result screen
Restart functionality
Navigation between screens using Navigator
Features
Multiple-choice questions
Automatic score calculation
Final result display
Restart quiz button
Simple and responsive user interface
Technologies Used
Flutter
Dart
Material Design
Screenshots
Quiz Screen

(Add screenshot here)

Result Screen

(Add screenshot here)

How to Run
flutter pub get
flutter run
