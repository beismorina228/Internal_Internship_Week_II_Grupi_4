# Day 2 - Student Profile App

## Description

This Flutter application allows users to add and manage student profiles. Users can enter a student's name and email address, validate the information, and display students in a dynamic list.

## Features

* Add new student profiles
* Name validation
* Email validation
* Error messages using SnackBar
* Dynamic student list
* Responsive user interface
* Clean and organized code structure

## Technologies Used

* Flutter
* Dart
* Material Design

## How to Run

1. Open the project in FlutLab, Android Studio, or VS Code.
2. Run `flutter pub get`.
3. Start the application using `flutter run`.

## Validation Rules

* Name field cannot be empty.
* Email field cannot be empty.
* Email must contain a valid format.

## Screenshots

Add screenshots of:

1. Empty form
2. Validation error messages
3. Student list after adding profiles

## Learning Objectives

* Using StatefulWidget
* Working with TextEditingController
* Form validation
* Managing lists in Flutter
* Displaying dynamic data with ListView

## Commit History

* add student form
* add validation
* add student list

Final commit:

day2 student profile app
