package com.example.day2_task2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
