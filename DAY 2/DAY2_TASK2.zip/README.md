# Day 2 - Registration Form

## Description

A Flutter registration form with validation and visual feedback.

## Features

* Name field
* Email validation
* Password validation
* Role selection
* Error messages
* Success dialog
* Responsive design

## Technologies

* Flutter
* Dart
* Material Design

## Commit

day2 registration form
