import 'package:flutter/material.dart';

void main() {
  runApp(const RegistrationFormApp());
}

class RegistrationFormApp extends StatelessWidget {
  const RegistrationFormApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Registration Form',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6750A4),
        ),
        useMaterial3: true,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(
              color: Color(0xFF6750A4),
              width: 2,
            ),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Colors.red),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(
              color: Colors.red,
              width: 2,
            ),
          ),
        ),
      ),
      home: const RegistrationPage(),
    );
  }
}

class RegistrationPage extends StatefulWidget {
  const RegistrationPage({super.key});

  @override
  State<RegistrationPage> createState() => _RegistrationPageState();
}

class _RegistrationPageState extends State<RegistrationPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  final List<String> _roles = <String>[
    'Student',
    'Intern',
    'Developer',
  ];

  final List<String> _statuses = <String>[
    'Active',
    'Inactive',
  ];

  String _selectedRole = 'Student';
  String _selectedStatus = 'Active';
  bool _hidePassword = true;
  bool _isSubmitting = false;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  String? _validateName(String? value) {
    final String name = value?.trim() ?? '';

    if (name.isEmpty) {
      return 'Ju lutem shkruani emrin.';
    }

    if (name.length < 2) {
      return 'Emri duhet të ketë të paktën 2 karaktere.';
    }

    return null;
  }

  String? _validateEmail(String? value) {
    final String email = value?.trim() ?? '';

    if (email.isEmpty) {
      return 'Ju lutem shkruani email-in.';
    }

    final RegExp emailPattern = RegExp(
      r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$',
    );

    if (!emailPattern.hasMatch(email)) {
      return 'Shkruani një email valid, p.sh. emri@example.com.';
    }

    return null;
  }

  String? _validatePassword(String? value) {
    final String password = value ?? '';

    if (password.isEmpty) {
      return 'Ju lutem shkruani password-in.';
    }

    if (password.length < 6) {
      return 'Password-i duhet të ketë të paktën 6 karaktere.';
    }

    return null;
  }

  Future<void> _submitForm() async {
    FocusScope.of(context).unfocus();

    final bool isValid = _formKey.currentState?.validate() ?? false;
    if (!isValid) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Kontrolloni fushat me gabime.'),
        ),
      );
      return;
    }

    setState(() {
      _isSubmitting = true;
    });

    final String registeredName = _nameController.text.trim();
    final String registeredEmail = _emailController.text.trim();
    final String registeredRole = _selectedRole;
    final String registeredStatus = _selectedStatus;

    await Future<void>.delayed(const Duration(milliseconds: 300));

    if (!mounted) {
      return;
    }

    setState(() {
      _isSubmitting = false;
    });

    await showDialog<void>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          icon: const Icon(
            Icons.check_circle,
            color: Colors.green,
            size: 48,
          ),
          title: const Text('Regjistrimi u krye!'),
          content: SizedBox(
            width: 380,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                _SummaryRow(label: 'Emri', value: registeredName),
                _SummaryRow(label: 'Email', value: registeredEmail),
                _SummaryRow(label: 'Roli', value: registeredRole),
                _SummaryRow(label: 'Statusi', value: registeredStatus),
                const _SummaryRow(
                  label: 'Password',
                  value: 'U pranua me sukses',
                ),
              ],
            ),
          ),
          actions: <Widget>[
            FilledButton(
              onPressed: () {
                Navigator.of(dialogContext).pop();
              },
              child: const Text('Në rregull'),
            ),
          ],
        );
      },
    );

    if (!mounted) {
      return;
    }

    _nameController.clear();
    _emailController.clear();
    _passwordController.clear();

    setState(() {
      _hidePassword = true;
      _selectedRole = 'Student';
      _selectedStatus = 'Active';
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Forma u pastrua dhe është gati për regjistrim të ri.'),
      ),
    );
  }

  Widget _buildNameField() {
    return TextFormField(
      controller: _nameController,
      textInputAction: TextInputAction.next,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      validator: _validateName,
      decoration: const InputDecoration(
        labelText: 'Emri',
        hintText: 'Shkruani emrin e plotë',
        prefixIcon: Icon(Icons.person_outline),
        errorMaxLines: 2,
      ),
    );
  }

  Widget _buildEmailField() {
    return TextFormField(
      controller: _emailController,
      keyboardType: TextInputType.emailAddress,
      textInputAction: TextInputAction.next,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      validator: _validateEmail,
      decoration: const InputDecoration(
        labelText: 'Email',
        hintText: 'emri@example.com',
        prefixIcon: Icon(Icons.email_outlined),
        errorMaxLines: 2,
      ),
    );
  }

  Widget _buildPasswordField() {
    return TextFormField(
      controller: _passwordController,
      obscureText: _hidePassword,
      textInputAction: TextInputAction.done,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      validator: _validatePassword,
      onFieldSubmitted: (_) => _submitForm(),
      decoration: InputDecoration(
        labelText: 'Password',
        hintText: 'Minimum 6 karaktere',
        prefixIcon: const Icon(Icons.lock_outline),
        errorMaxLines: 2,
        suffixIcon: IconButton(
          tooltip: _hidePassword
              ? 'Shfaq password-in'
              : 'Fshih password-in',
          onPressed: () {
            setState(() {
              _hidePassword = !_hidePassword;
            });
          },
          icon: Icon(
            _hidePassword ? Icons.visibility_outlined : Icons.visibility_off,
          ),
        ),
      ),
    );
  }

  Widget _buildRoleField() {
    return DropdownButtonFormField<String>(
      value: _selectedRole,
      decoration: const InputDecoration(
        labelText: 'Roli',
        prefixIcon: Icon(Icons.badge_outlined),
      ),
      items: _roles.map((String role) {
        return DropdownMenuItem<String>(
          value: role,
          child: Text(role),
        );
      }).toList(),
      onChanged: (String? value) {
        if (value == null) {
          return;
        }

        setState(() {
          _selectedRole = value;
        });
      },
    );
  }

  Widget _buildStatusField() {
    return DropdownButtonFormField<String>(
      value: _selectedStatus,
      decoration: const InputDecoration(
        labelText: 'Statusi',
        prefixIcon: Icon(Icons.toggle_on_outlined),
      ),
      items: _statuses.map((String status) {
        return DropdownMenuItem<String>(
          value: status,
          child: Text(status),
        );
      }).toList(),
      onChanged: (String? value) {
        if (value == null) {
          return;
        }

        setState(() {
          _selectedStatus = value;
        });
      },
    );
  }

  Widget _buildMobileFields() {
    return Column(
      children: <Widget>[
        _buildNameField(),
        const SizedBox(height: 16),
        _buildEmailField(),
        const SizedBox(height: 16),
        _buildPasswordField(),
        const SizedBox(height: 16),
        _buildRoleField(),
        const SizedBox(height: 16),
        _buildStatusField(),
      ],
    );
  }

  Widget _buildDesktopFields() {
    return Column(
      children: <Widget>[
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Expanded(child: _buildNameField()),
            const SizedBox(width: 16),
            Expanded(child: _buildEmailField()),
          ],
        ),
        const SizedBox(height: 16),
        _buildPasswordField(),
        const SizedBox(height: 16),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Expanded(child: _buildRoleField()),
            const SizedBox(width: 16),
            Expanded(child: _buildStatusField()),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F3FB),
      appBar: AppBar(
        title: const Text('Registration Form'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
            final bool useDesktopLayout = constraints.maxWidth >= 760;

            return SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 820),
                  child: Card(
                    elevation: 4,
                    clipBehavior: Clip.antiAlias,
                    child: Padding(
                      padding: EdgeInsets.all(useDesktopLayout ? 36 : 22),
                      child: Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: <Widget>[
                            const Icon(
                              Icons.app_registration,
                              size: 64,
                              color: Color(0xFF6750A4),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              'Krijo llogarinë',
                              textAlign: TextAlign.center,
                              style: Theme.of(context)
                                  .textTheme
                                  .headlineMedium
                                  ?.copyWith(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Plotësoni të dhënat dhe kontrolloni gabimet para regjistrimit.',
                              textAlign: TextAlign.center,
                              style: Theme.of(context).textTheme.bodyMedium,
                            ),
                            const SizedBox(height: 28),
                            if (useDesktopLayout)
                              _buildDesktopFields()
                            else
                              _buildMobileFields(),
                            const SizedBox(height: 26),
                            SizedBox(
                              height: 52,
                              child: FilledButton.icon(
                                onPressed:
                                    _isSubmitting ? null : _submitForm,
                                icon: _isSubmitting
                                    ? const SizedBox(
                                        width: 20,
                                        height: 20,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                        ),
                                      )
                                    : const Icon(Icons.person_add_alt_1),
                                label: Text(
                                  _isSubmitting
                                      ? 'Duke u regjistruar...'
                                      : 'Regjistrohu',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  const _SummaryRow({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            width: 90,
            child: Text(
              '$label:',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }
}
