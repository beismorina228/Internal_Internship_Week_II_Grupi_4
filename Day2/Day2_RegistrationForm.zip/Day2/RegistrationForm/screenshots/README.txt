Vendose këtu screenshot-in pas ekzekutimit.
