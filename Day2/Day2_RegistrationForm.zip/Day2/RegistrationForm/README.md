# Day 2 – Registration Form

Ky projekt është krijuar për detyrën **Internal Internship – Day 2, Task 2**.

## Përmban

- emër, email, password, rol dhe status;
- validim të emrit, email-it dhe password-it;
- mesazhe gabimi nën fusha;
- dialog përmbledhës pas regjistrimit;
- UI responsive për mobile dhe desktop;
- buton për shfaqjen/fshihjen e password-it.

## Ekzekutimi

Nëse mungojnë platform files:

```bash
flutter create .
```

Pastaj:

```bash
flutter pub get
flutter run -d chrome
```

## GitHub

```bash
git add .
git commit -m "day2 registration form"
git push
```

## Screenshot

Vendose screenshot-in në folderin `screenshots/` me emrin `registration_form.png`.

## Pjesët kryesore

- `Form` dhe `GlobalKey<FormState>` kontrollojnë validimin.
- `TextFormField` merr të dhënat dhe shfaq gabimet.
- `TextEditingController` lexon tekstin.
- `DropdownButtonFormField` zgjedh rolin dhe statusin.
- `showDialog()` shfaq përmbledhjen.
- `LayoutBuilder` e bën ekranin responsive.
- `dispose()` liron controller-at.
