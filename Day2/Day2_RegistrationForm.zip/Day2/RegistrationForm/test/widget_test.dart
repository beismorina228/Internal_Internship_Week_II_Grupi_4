import 'package:flutter_test/flutter_test.dart';
import 'package:day2_registration_form/main.dart';

void main() {
  testWidgets('Registration form loads', (WidgetTester tester) async {
    await tester.pumpWidget(const RegistrationFormApp());
    expect(find.text('Krijo llogarinë'), findsOneWidget);
    expect(find.text('Regjistrohu'), findsOneWidget);
  });
}
