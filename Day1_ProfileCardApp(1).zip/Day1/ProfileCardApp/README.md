# Profile Card App

Internal Internship – Day 1 – Task 1.

## Description

A responsive Flutter profile card that presents a professional profile with a name, role, short description, contact information, location, and an interactive contact button.

## Features

- MaterialApp and Scaffold
- Responsive Card layout for mobile and desktop
- Row, Column, Padding, Container, and SizedBox
- Profile icon, name, role, description, email, and location
- Button that changes the status text with `setState()`
- SnackBar confirmation message
- No external packages required

## How to run

1. Install Flutter and open this folder in VS Code.
2. Run:

```bash
flutter pub get
flutter run -d chrome
```

To test the project:

```bash
flutter test
```

## Git commands

```bash
git checkout -b Eljesa-Shehu
git add .
git commit -m "day1 profile card"
git push -u origin Eljesa-Shehu
```

## Screenshot

Add your application screenshot here after running the project:

```markdown
![Profile Card App](screenshot.png)
```
