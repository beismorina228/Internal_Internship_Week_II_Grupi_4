import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:profile_card_app/main.dart';

void main() {
  testWidgets('Profile card displays main information and button works',
      (WidgetTester tester) async {
    await tester.pumpWidget(const ProfileCardApp());

    expect(find.text('Eljesa Shehu'), findsOneWidget);
    expect(find.text('Flutter Developer Intern'), findsOneWidget);
    expect(find.text('Contact Me'), findsOneWidget);

    await tester.tap(find.byType(ElevatedButton));
    await tester.pump();

    expect(find.text('Message sent successfully!'), findsOneWidget);
    expect(find.text('Thank you for contacting me!'), findsOneWidget);
  });
}
