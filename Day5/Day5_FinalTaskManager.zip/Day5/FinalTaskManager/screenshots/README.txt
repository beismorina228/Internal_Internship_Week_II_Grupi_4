Vendosi këtu screenshot-et:
- home_screen.png
- task_form_screen.png
- task_details_screen.png
