class Task {
  Task({
    required this.id,
    required this.title,
    required this.description,
    required this.priority,
    this.isDone = false,
  });

  final int id;
  String title;
  String description;
  String priority;
  bool isDone;
}
