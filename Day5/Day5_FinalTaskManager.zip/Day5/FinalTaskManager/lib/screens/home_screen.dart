import 'package:flutter/material.dart';
import '../models/task.dart';
import 'task_details_screen.dart';
import 'task_form_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<Task> _tasks = [
    Task(
      id: 1,
      title: 'Mëso Flutter',
      description: 'Përsërit state, navigation dhe validimin.',
      priority: 'High',
    ),
    Task(
      id: 2,
      title: 'Përfundo projektin final',
      description: 'Kontrollo README dhe bëj commit.',
      priority: 'Medium',
    ),
  ];

  int get _doneCount => _tasks.where((task) => task.isDone).length;
  int get _activeCount => _tasks.where((task) => !task.isDone).length;

  Future<void> _openForm({Task? task}) async {
    final result = await Navigator.push<Task>(
      context,
      MaterialPageRoute(builder: (_) => TaskFormScreen(task: task)),
    );
    if (result == null) return;

    setState(() {
      if (task == null) {
        _tasks.add(result);
      } else {
        final index = _tasks.indexWhere((item) => item.id == task.id);
        if (index != -1) _tasks[index] = result;
      }
    });

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(task == null ? 'Detyra u shtua.' : 'Detyra u ndryshua.')),
    );
  }

  void _toggle(Task task) {
    setState(() => task.isDone = !task.isDone);
  }

  Future<void> _delete(Task task) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Konfirmo fshirjen'),
        content: Text('A dëshiron ta fshish "${task.title}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Anulo'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Fshije'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;
    setState(() => _tasks.remove(task));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Detyra u fshi.')),
    );
  }

  Future<void> _openDetails(Task task) async {
    final action = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => TaskDetailsScreen(task: task)),
    );
    if (action == 'edit') {
      await _openForm(task: task);
    } else if (action == 'delete') {
      await _delete(task);
    }
  }

  Widget _summary(String title, int value, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(child: Icon(icon)),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title),
                Text('$value', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F3FB),
      appBar: AppBar(title: const Text('Task Manager'), centerTitle: true),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openForm(),
        icon: const Icon(Icons.add),
        label: const Text('Shto detyrë'),
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final desktop = constraints.maxWidth >= 760;
          return SingleChildScrollView(
            padding: const EdgeInsets.all(18),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 950),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text('Detyrat e mia', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    const Text('Shto, edito, përfundo dhe fshi detyra.'),
                    const SizedBox(height: 18),
                    if (desktop)
                      Row(
                        children: [
                          Expanded(child: _summary('Gjithsej', _tasks.length, Icons.list_alt)),
                          const SizedBox(width: 12),
                          Expanded(child: _summary('Aktive', _activeCount, Icons.pending_actions)),
                          const SizedBox(width: 12),
                          Expanded(child: _summary('Done', _doneCount, Icons.task_alt)),
                        ],
                      )
                    else
                      Column(
                        children: [
                          _summary('Gjithsej', _tasks.length, Icons.list_alt),
                          _summary('Aktive', _activeCount, Icons.pending_actions),
                          _summary('Done', _doneCount, Icons.task_alt),
                        ],
                      ),
                    const SizedBox(height: 18),
                    if (_tasks.isEmpty)
                      const Card(child: Padding(padding: EdgeInsets.all(28), child: Text('Nuk ka detyra.', textAlign: TextAlign.center)))
                    else
                      ..._tasks.map(
                        (task) => Card(
                          margin: const EdgeInsets.only(bottom: 12),
                          child: ListTile(
                            onTap: () => _openDetails(task),
                            leading: Checkbox(value: task.isDone, onChanged: (_) => _toggle(task)),
                            title: Text(
                              task.title,
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                decoration: task.isDone ? TextDecoration.lineThrough : null,
                              ),
                            ),
                            subtitle: Text('${task.priority} • ${task.isDone ? 'Done' : 'Active'}'),
                            trailing: PopupMenuButton<String>(
                              onSelected: (value) {
                                if (value == 'edit') _openForm(task: task);
                                if (value == 'delete') _delete(task);
                              },
                              itemBuilder: (_) => const [
                                PopupMenuItem(value: 'edit', child: Text('Edito')),
                                PopupMenuItem(value: 'delete', child: Text('Fshije')),
                              ],
                            ),
                          ),
                        ),
                      ),
                    const SizedBox(height: 90),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
