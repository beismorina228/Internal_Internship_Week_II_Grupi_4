# Day 5 – Final Project: Task Manager

## MVP
Ky aplikacion Flutter përmban:

1. Shtim të detyrave.
2. Editim dhe fshirje.
3. Ndryshim të statusit Active/Done.
4. Home Screen, Form Screen dhe Details Screen.
5. Validim, navigation, SnackBar dhe AlertDialog.
6. UI responsive për mobile dhe desktop.

## Struktura

```text
lib/
├── main.dart
├── models/
│   └── task.dart
└── screens/
    ├── home_screen.dart
    ├── task_form_screen.dart
    └── task_details_screen.dart
```

## Ekzekutimi

```bash
flutter create .
flutter pub get
flutter run -d chrome
```

## Commit-et

```bash
git add .
git commit -m "day5 create task model and screens"

git add .
git commit -m "day5 add task form and validation"

git add .
git commit -m "day5 add edit delete and navigation"

git add .
git commit -m "day5 final project"

git push
```

## Reflektim
Kam përdorur njohuritë nga Day 1–4: widgets, state management, forma, validim, lista dinamike dhe navigation.
