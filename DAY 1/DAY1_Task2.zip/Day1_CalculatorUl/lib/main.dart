import 'package:flutter/material.dart';

void main() {
  runApp(const GradeCalculatorApp());
}

class GradeCalculatorApp extends StatelessWidget {
  const GradeCalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Grade Calculator',
      theme: ThemeData(useMaterial3: true),
      home: const GradeCalculatorPage(),
    );
  }
}

class GradeCalculatorPage extends StatefulWidget {
  const GradeCalculatorPage({super.key});

  @override
  State<GradeCalculatorPage> createState() => _GradeCalculatorPageState();
}

class _GradeCalculatorPageState extends State<GradeCalculatorPage> {
  final _formKey = GlobalKey<FormState>();

  final grade1 = TextEditingController();
  final grade2 = TextEditingController();
  final grade3 = TextEditingController();

  double? average;
  String status = "";

  String? validate(String? value) {
    if (value == null || value.trim().isEmpty) {
      return "This field is required";
    }
    if (double.tryParse(value) == null) {
      return "Enter a valid number";
    }
    return null;
  }

  void calculate() {
    if (_formKey.currentState!.validate()) {
      final g1 = double.parse(grade1.text);
      final g2 = double.parse(grade2.text);
      final g3 = double.parse(grade3.text);

      final result = (g1 + g2 + g3) / 3;

      setState(() {
        average = result;
        status = result >= 50 ? "Pass" : "Needs Improvement";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Grade Calculator UI")),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 500),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        "Enter Three Grades",
                        style: TextStyle(
                            fontSize: 22, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 20),
                      TextFormField(
                        controller: grade1,
                        validator: validate,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: "Grade 1",
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: grade2,
                        validator: validate,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: "Grade 2",
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: grade3,
                        validator: validate,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: "Grade 3",
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: calculate,
                        child: const Text("Calculate Average"),
                      ),
                      const SizedBox(height: 20),
                      if (average != null)
                        Column(
                          children: [
                            Text(
                              "Average: ${average!.toStringAsFixed(2)}",
                              style: const TextStyle(
                                  fontSize: 20, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 8),
                            Text(status, style: const TextStyle(fontSize: 18)),
                          ],
                        )
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
