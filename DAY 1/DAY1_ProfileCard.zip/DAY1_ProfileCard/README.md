# Day 1 - Profile Card App

## Description

A simple Flutter application that displays a professional profile card.

## Features

* Name
* Role
* Short description
* Profile icon
* Responsive UI
* Button with SnackBar
* Clean Material Design

## Technologies

* Flutter
* Dart

## Commit Message

day1 profile card
