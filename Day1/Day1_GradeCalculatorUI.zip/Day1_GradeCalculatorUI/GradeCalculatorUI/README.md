# Grade Calculator UI

Projekt Flutter për Internal Internship - Day 1.

## Përshkrimi

Aplikacioni merr tri nota numerike nga përdoruesi, kontrollon nëse fushat janë plotësuar saktë dhe llogarit mesataren me dy shifra pas presjes.

## Funksionet

- Tri fusha `TextField`
- Validim për fusha të zbrazëta
- Validim për vlera jo-numerike
- Validim që notat janë nga 1 deri në 5
- Mesatare me dy shifra pas presjes
- Statusi `Kalon` ose `Duhet përmirësim`
- Buton për pastrimin e fushave
- Dizajn responsive për mobile dhe desktop

## Si të ekzekutohet

```bash
flutter create .
flutter pub get
flutter run -d chrome
```

## Commit

```bash
git add .
git commit -m "day1 calculator ui"
git push
```

## Screenshot

Vendos screenshot-in këtu:

`docs/grade_calculator_screenshot.png`
