import 'package:flutter_test/flutter_test.dart';
import 'package:grade_calculator_ui/main.dart';

void main() {
  testWidgets('Grade calculator title is displayed', (tester) async {
    await tester.pumpWidget(const GradeCalculatorApp());

    expect(find.text('Llogaritësi i Mesatares'), findsOneWidget);
    expect(find.text('Llogarit'), findsOneWidget);
  });
}
