import 'package:flutter/material.dart';

void main() {
  runApp(const GradeCalculatorApp());
}

class GradeCalculatorApp extends StatelessWidget {
  const GradeCalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Grade Calculator',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const GradeCalculatorPage(),
    );
  }
}

class GradeCalculatorPage extends StatefulWidget {
  const GradeCalculatorPage({super.key});

  @override
  State<GradeCalculatorPage> createState() => _GradeCalculatorPageState();
}

class _GradeCalculatorPageState extends State<GradeCalculatorPage> {
  final TextEditingController firstGradeController = TextEditingController();
  final TextEditingController secondGradeController = TextEditingController();
  final TextEditingController thirdGradeController = TextEditingController();

  String averageText = 'Mesatarja: --';
  String statusText = 'Statusi: --';
  Color statusColor = Colors.grey;

  @override
  void dispose() {
    firstGradeController.dispose();
    secondGradeController.dispose();
    thirdGradeController.dispose();
    super.dispose();
  }

  void calculateAverage() {
    final String firstInput = firstGradeController.text.trim();
    final String secondInput = secondGradeController.text.trim();
    final String thirdInput = thirdGradeController.text.trim();

    if (firstInput.isEmpty || secondInput.isEmpty || thirdInput.isEmpty) {
      showMessage('Ju lutem plotësoni të gjitha fushat.');
      return;
    }

    final double? firstGrade = double.tryParse(firstInput);
    final double? secondGrade = double.tryParse(secondInput);
    final double? thirdGrade = double.tryParse(thirdInput);

    if (firstGrade == null || secondGrade == null || thirdGrade == null) {
      showMessage('Shkruani vetëm vlera numerike.');
      return;
    }

    if (!_isValidGrade(firstGrade) ||
        !_isValidGrade(secondGrade) ||
        !_isValidGrade(thirdGrade)) {
      showMessage('Notat duhet të jenë nga 1 deri në 5.');
      return;
    }

    final double average = (firstGrade + secondGrade + thirdGrade) / 3;
    final bool hasPassed = average >= 2.0;

    setState(() {
      averageText = 'Mesatarja: ${average.toStringAsFixed(2)}';
      statusText = hasPassed ? 'Statusi: Kalon' : 'Statusi: Duhet përmirësim';
      statusColor = hasPassed ? Colors.green : Colors.red;
    });
  }

  bool _isValidGrade(double grade) {
    return grade >= 1 && grade <= 5;
  }

  void clearFields() {
    firstGradeController.clear();
    secondGradeController.clear();
    thirdGradeController.clear();

    setState(() {
      averageText = 'Mesatarja: --';
      statusText = 'Statusi: --';
      statusColor = Colors.grey;
    });
  }

  void showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Widget buildGradeField({
    required String label,
    required TextEditingController controller,
  }) {
    return TextField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(
        labelText: label,
        hintText: 'Shkruaj një notë 1-5',
        prefixIcon: const Icon(Icons.grade_outlined),
        border: const OutlineInputBorder(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Grade Calculator'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: Card(
                elevation: 5,
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Icon(
                        Icons.calculate_outlined,
                        size: 70,
                        color: Colors.indigo,
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'Llogaritësi i Mesatares',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Shkruani tri nota nga 1 deri në 5.',
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 24),
                      buildGradeField(
                        label: 'Nota 1',
                        controller: firstGradeController,
                      ),
                      const SizedBox(height: 16),
                      buildGradeField(
                        label: 'Nota 2',
                        controller: secondGradeController,
                      ),
                      const SizedBox(height: 16),
                      buildGradeField(
                        label: 'Nota 3',
                        controller: thirdGradeController,
                      ),
                      const SizedBox(height: 22),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              onPressed: calculateAverage,
                              icon: const Icon(Icons.calculate),
                              label: const Text('Llogarit'),
                              style: ElevatedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(vertical: 15),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: clearFields,
                              icon: const Icon(Icons.refresh),
                              label: const Text('Pastro'),
                              style: OutlinedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(vertical: 15),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),
                      Container(
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          color: Colors.indigo.shade50,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          children: [
                            Text(
                              averageText,
                              style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              statusText,
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                                color: statusColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
